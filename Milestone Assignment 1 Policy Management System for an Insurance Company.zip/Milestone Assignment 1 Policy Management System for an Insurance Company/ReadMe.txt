
Instructions on how to Run the Codes

Please run the codes that have been saved in four different files using VS Code.
Files created;
	1.Main_Policy_Mgt
	2.Class_Payments
	3.Class_PolicyHolder
	4.Class_Products

The link to Github is:
	
https://github.com/JacksonMulera/Milestone-Assignment-1-Policy-Management-System-for-an-Insurance-Company	

	Thanks.