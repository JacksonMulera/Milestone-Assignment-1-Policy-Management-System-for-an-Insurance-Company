# Creating class for payments:
class Payments:
    def __init__(self, policyholder, product, date, amount, payment_status):
        self.policyholder = policyholder
        self.product = product
        self.date = date
        self.amount = amount
        self.payment_status = payment_status

    # Processing payments which have been paid and which are pending
    def process_payment(self):
        if self.payment_status == "Pending":
            print(f"{self.policyholder.name} has NOT PAID ${self.amount} for {self.product.name} as at {self.date}")
        else:
            if self.payment_status == "Paid":
                print(f"{self.policyholder.name} paid ${self.amount} for {self.product.name} on {self.date}")

    def send_reminder(self):
        if self.payment_status == "Pending":
            print(f"Reminder: {self.policyholder.name} has to pay ${self.amount} for {self.product.name} by {self.date}")
        else:
            print(f"No reminder needed for {self.policyholder.name}")

    def apply_penalty(self):
        if self.payment_status == "Pending":
            penalty = self.amount * 0.1
            self.amount += penalty
            print(
                f"Penalty: {self.policyholder.name} has to pay an extra ${penalty} for {self.product.name} due to late payment")
        else:
            print(f"No penalty needed for {self.policyholder.name}")