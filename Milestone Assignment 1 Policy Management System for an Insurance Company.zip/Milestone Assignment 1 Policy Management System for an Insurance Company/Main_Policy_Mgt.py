
# Importing class files:

from Class_PolicyHolder import Policyholder
from Class_Payments import Payments
from Class_Products import Products

# Creating four sample policyholders
ph1 = Policyholder("Jackson Mulera", "Z001", "Active")
ph2 = Policyholder("Gibendi Tim", "Z002", "Suspended")
ph3 = Policyholder("Tom Daktari ", "Z003", "Active")
ph4 = Policyholder("Geoffrey Lwimbu", "Z004","Suspended")

# Registering four sample products for the policyholders
p1 = Products("Life Insurance", 1001, 15)
p2 = Products("Motor Insurance", 504, 7)
p3 = Products("General Insurance", 2001, 17)
p4 = Products("Health Insurance", 3001, 18)

# Creating four sample payments
pay1 = Payments(ph1, p1, "2024-01-01", 1000, "Pending")
pay2 = Payments(ph2, p2, "2024-02-02", 1500, "Paid")
pay3 = Payments(ph3, p3, "2023-03-03", 2000, "Pending")
pay4 = Payments(ph4, p4, "2023-04-04", 2500, "Paid")

# Displaying the policyholders
ph1.display()
ph2.display()
ph3.display()
ph4.display()

# Processing payments
pay1.process_payment()
pay2.process_payment()
pay3.process_payment()
pay4.process_payment()

# Sending  reminders
pay1.send_reminder()
pay2.send_reminder()
pay3.send_reminder()
pay4.send_reminder()

# Applying penalties
pay1.apply_penalty()
pay2.apply_penalty()
pay3.apply_penalty()
pay3.apply_penalty()